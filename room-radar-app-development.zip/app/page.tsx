import { RoomRadar } from '@/components/room-radar'

export default function Page() {
  return <RoomRadar />
}
