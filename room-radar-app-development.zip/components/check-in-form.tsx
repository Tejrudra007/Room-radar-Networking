'use client'

import { useId, useState, type FormEvent } from 'react'
import { ChevronDown, LogIn } from 'lucide-react'
import { TAGS, type Tag } from '@/lib/attendees'

export type CheckInValues = {
  name: string
  role: string
  tag: Tag
  icebreaker: string
}

type CheckInFormProps = {
  onSubmit: (values: CheckInValues) => void
  checkedInName?: string | null
}

const fieldClass =
  'w-full rounded-lg border border-input bg-background/60 px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/70 transition-colors focus-visible:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring'

export function CheckInForm({ onSubmit, checkedInName }: CheckInFormProps) {
  const id = useId()
  const [name, setName] = useState('')
  const [role, setRole] = useState('')
  const [tag, setTag] = useState<Tag | ''>('')
  const [icebreaker, setIcebreaker] = useState('')
  const [error, setError] = useState<string | null>(null)

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const trimmedName = name.trim()
    const trimmedRole = role.trim()
    if (!trimmedName || !trimmedRole || !tag) {
      setError('Please fill in your name, major / role, and who you want to meet.')
      return
    }
    setError(null)
    onSubmit({
      name: trimmedName.slice(0, 60),
      role: trimmedRole.slice(0, 80),
      tag,
      icebreaker: icebreaker.trim().slice(0, 140),
    })
    setName('')
    setRole('')
    setTag('')
    setIcebreaker('')
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4" noValidate>
      <div className="flex flex-col gap-1.5">
        <label htmlFor={`${id}-name`} className="text-sm font-medium">
          Your Name
        </label>
        <input
          id={`${id}-name`}
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="e.g. Jordan Lee"
          autoComplete="name"
          maxLength={60}
          required
          className={fieldClass}
        />
      </div>

      <div className="flex flex-col gap-1.5">
        <label htmlFor={`${id}-role`} className="text-sm font-medium">
          Major / Role
        </label>
        <input
          id={`${id}-role`}
          value={role}
          onChange={(e) => setRole(e.target.value)}
          placeholder="e.g. Finance Junior · Aspiring PM"
          maxLength={80}
          required
          className={fieldClass}
        />
      </div>

      <div className="flex flex-col gap-1.5">
        <label htmlFor={`${id}-tag`} className="text-sm font-medium">
          Looking to Connect With
        </label>
        <div className="relative">
          <select
            id={`${id}-tag`}
            value={tag}
            onChange={(e) => setTag(e.target.value as Tag)}
            required
            className={`${fieldClass} appearance-none pr-10 ${tag ? '' : 'text-muted-foreground/70'}`}
          >
            <option value="" disabled>
              Select a group
            </option>
            {TAGS.map((t) => (
              <option key={t} value={t} className="bg-card text-foreground">
                {t}
              </option>
            ))}
          </select>
          <ChevronDown
            className="pointer-events-none absolute right-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
            aria-hidden="true"
          />
        </div>
      </div>

      <div className="flex flex-col gap-1.5">
        <label htmlFor={`${id}-icebreaker`} className="text-sm font-medium">
          Icebreaker <span className="font-normal text-muted-foreground">(optional)</span>
        </label>
        <input
          id={`${id}-icebreaker`}
          value={icebreaker}
          onChange={(e) => setIcebreaker(e.target.value)}
          placeholder="Ask me about..."
          maxLength={140}
          className={fieldClass}
        />
      </div>

      {error && (
        <p role="alert" className="text-sm text-destructive">
          {error}
        </p>
      )}

      <button
        type="submit"
        className="mt-1 inline-flex items-center justify-center gap-2 rounded-lg bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground shadow-[0_0_24px_-6px] shadow-primary/60 transition-colors hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-card"
      >
        <LogIn className="size-4" aria-hidden="true" />
        Check In to Room
      </button>

      <p className="text-xs text-muted-foreground" aria-live="polite">
        {checkedInName
          ? `You're in, ${checkedInName.split(' ')[0]}! Your card is live in the feed.`
          : 'Your card appears instantly in the live directory.'}
      </p>
    </form>
  )
}
