import { cn } from '@/lib/utils'
import { TAG_STYLES, type Tag } from '@/lib/attendees'

export type Filter = 'All' | Tag

type FilterBarProps = {
  filters: Filter[]
  active: Filter
  counts: Record<Filter, number>
  onChange: (filter: Filter) => void
}

export function FilterBar({ filters, active, counts, onChange }: FilterBarProps) {
  return (
    <div
      role="group"
      aria-label="Filter attendees by tag"
      className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-1 [scrollbar-width:none] sm:mx-0 sm:flex-wrap sm:px-0"
    >
      {filters.map((filter) => {
        const isActive = filter === active
        return (
          <button
            key={filter}
            type="button"
            aria-pressed={isActive}
            onClick={() => onChange(filter)}
            className={cn(
              'inline-flex shrink-0 items-center gap-2 rounded-full border px-4 py-2 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
              isActive
                ? 'border-primary/50 bg-primary/10 text-primary'
                : 'border-border bg-card text-muted-foreground hover:bg-accent hover:text-foreground',
            )}
          >
            {filter !== 'All' && (
              <span className={cn('size-2 rounded-full', TAG_STYLES[filter].dot)} aria-hidden="true" />
            )}
            {filter}
            <span
              className={cn(
                'rounded-full px-1.5 font-mono text-xs tabular-nums',
                isActive ? 'bg-primary/20 text-primary' : 'bg-muted text-muted-foreground',
              )}
            >
              {counts[filter]}
            </span>
          </button>
        )
      })}
    </div>
  )
}
