import { Radar } from 'lucide-react'

type RoomHeaderProps = {
  attendeeCount: number
  onCheckInClick: () => void
}

export function RoomHeader({ attendeeCount, onCheckInClick }: RoomHeaderProps) {
  return (
    <header className="sticky top-0 z-30 border-b border-border bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-4 sm:px-6">
        <div className="flex min-w-0 items-center gap-3">
          <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary ring-1 ring-primary/30">
            <Radar className="size-5" aria-hidden="true" />
          </div>
          <div className="min-w-0">
            <h1 className="truncate text-base font-semibold tracking-tight text-balance sm:text-lg">
              RoomRadar <span className="text-muted-foreground">-</span>{' '}
              <span className="text-muted-foreground font-normal">Live CEL Mixer Feed</span>
            </h1>
            <p className="mt-0.5 flex items-center gap-2 text-xs text-muted-foreground sm:text-sm" aria-live="polite">
              <span className="relative flex size-2.5" aria-hidden="true">
                <span className="absolute inline-flex size-full animate-ping rounded-full bg-primary opacity-75" />
                <span className="relative inline-flex size-2.5 rounded-full bg-primary" />
              </span>
              <span>
                <span className="font-medium text-primary">Room Active</span> - {attendeeCount} Attendees
              </span>
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={onCheckInClick}
          className="shrink-0 rounded-lg bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background lg:hidden"
        >
          Check In
        </button>
      </div>
    </header>
  )
}
