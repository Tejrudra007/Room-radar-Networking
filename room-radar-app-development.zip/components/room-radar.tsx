'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { Users, X } from 'lucide-react'
import { RoomHeader } from '@/components/room-header'
import { CheckInForm, type CheckInValues } from '@/components/check-in-form'
import { FilterBar, type Filter } from '@/components/filter-bar'
import { AttendeeCard } from '@/components/attendee-card'
import { SEED_ATTENDEES, TAGS, buildIcebreaker, type Attendee } from '@/lib/attendees'

const FILTERS: Filter[] = ['All', ...TAGS]
const UNLISTED_ATTENDEES = 8

export function RoomRadar() {
  const [attendees, setAttendees] = useState<Attendee[]>(SEED_ATTENDEES)
  const [filter, setFilter] = useState<Filter>('All')
  const [myId, setMyId] = useState<string | null>(null)
  const [now, setNow] = useState(() => Date.now())
  const dialogRef = useRef<HTMLDialogElement>(null)

  useEffect(() => {
    const interval = setInterval(() => setNow(Date.now()), 30_000)
    return () => clearInterval(interval)
  }, [])

  const counts = useMemo(() => {
    const result = { All: attendees.length } as Record<Filter, number>
    for (const tag of TAGS) result[tag] = attendees.filter((a) => a.tag === tag).length
    return result
  }, [attendees])

  const visible = filter === 'All' ? attendees : attendees.filter((a) => a.tag === filter)
  const me = attendees.find((a) => a.id === myId)

  function handleCheckIn(values: CheckInValues) {
    const attendee: Attendee = {
      id: crypto.randomUUID(),
      name: values.name,
      role: values.role,
      tag: values.tag,
      icebreaker: values.icebreaker || buildIcebreaker(values.tag, values.role),
      checkedInAt: Date.now(),
    }
    setAttendees((prev) => [attendee, ...prev])
    setMyId(attendee.id)
    setNow(Date.now())
    setFilter('All')
    dialogRef.current?.close()
  }

  return (
    <div className="min-h-dvh bg-background">
      <div
        className="pointer-events-none fixed inset-x-0 top-0 h-80 bg-[radial-gradient(ellipse_at_top,var(--color-primary)_0%,transparent_70%)] opacity-[0.07]"
        aria-hidden="true"
      />
      <RoomHeader
        attendeeCount={attendees.length + UNLISTED_ATTENDEES}
        onCheckInClick={() => dialogRef.current?.showModal()}
      />

      <main className="relative mx-auto grid max-w-6xl gap-8 px-4 py-6 sm:px-6 sm:py-8 lg:grid-cols-[320px_1fr]">
        <aside className="hidden lg:block">
          <section
            aria-labelledby="checkin-heading"
            className="sticky top-24 rounded-2xl border border-border bg-card p-6"
          >
            <h2 id="checkin-heading" className="text-lg font-semibold tracking-tight">
              Check in
            </h2>
            <p className="mt-1 mb-5 text-sm text-muted-foreground">
              Drop your card into the room so the right people can find you.
            </p>
            <CheckInForm onSubmit={handleCheckIn} checkedInName={me?.name} />
          </section>
        </aside>

        <section aria-labelledby="directory-heading" className="flex min-w-0 flex-col gap-5">
          <div className="flex flex-col gap-1">
            <h2 id="directory-heading" className="flex items-center gap-2 text-xl font-semibold tracking-tight">
              <Users className="size-5 text-primary" aria-hidden="true" />
              Live Attendee Directory
            </h2>
            <p className="text-sm text-muted-foreground">
              {"Who's here right now. Tap an icebreaker to start a conversation."}
            </p>
          </div>

          <FilterBar filters={FILTERS} active={filter} counts={counts} onChange={setFilter} />

          {visible.length > 0 ? (
            <ul className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3" aria-live="polite">
              {visible.map((attendee) => (
                <li key={attendee.id} className="flex [&>*]:flex-1">
                  <AttendeeCard attendee={attendee} now={now} isYou={attendee.id === myId} />
                </li>
              ))}
            </ul>
          ) : (
            <div className="rounded-2xl border border-dashed border-border px-6 py-12 text-center">
              <p className="font-medium">No {filter} attendees yet</p>
              <p className="mt-1 text-sm text-muted-foreground">Check back in a few minutes — the room is filling up.</p>
            </div>
          )}
        </section>
      </main>

      <dialog
        ref={dialogRef}
        aria-labelledby="checkin-dialog-heading"
        onClick={(e) => {
          if (e.target === e.currentTarget) e.currentTarget.close()
        }}
        className="m-auto w-[calc(100%-2rem)] max-w-md rounded-2xl border border-border bg-card p-0 text-card-foreground backdrop:bg-black/70 backdrop:backdrop-blur-sm"
      >
        <div className="p-6">
          <div className="mb-5 flex items-start justify-between gap-4">
            <div>
              <h2 id="checkin-dialog-heading" className="text-lg font-semibold tracking-tight">
                Check in to the room
              </h2>
              <p className="mt-1 text-sm text-muted-foreground">
                Drop your card into the room so the right people can find you.
              </p>
            </div>
            <button
              type="button"
              onClick={() => dialogRef.current?.close()}
              className="rounded-md p-1 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              <X className="size-5" aria-hidden="true" />
              <span className="sr-only">Close</span>
            </button>
          </div>
          <CheckInForm onSubmit={handleCheckIn} checkedInName={me?.name} />
        </div>
      </dialog>
    </div>
  )
}
