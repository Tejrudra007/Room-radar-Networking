'use client'

import { useId, useState } from 'react'
import { ChevronDown, MessageCircle } from 'lucide-react'
import { cn } from '@/lib/utils'
import { TAG_STYLES, formatCheckIn, getInitials, type Attendee } from '@/lib/attendees'

type AttendeeCardProps = {
  attendee: Attendee
  now: number
  isYou?: boolean
}

export function AttendeeCard({ attendee, now, isYou }: AttendeeCardProps) {
  const [open, setOpen] = useState(false)
  const panelId = useId()
  const styles = TAG_STYLES[attendee.tag]

  return (
    <article
      className={cn(
        'flex flex-col rounded-2xl border bg-card p-5 transition-colors animate-in fade-in slide-in-from-bottom-2 duration-500',
        isYou ? 'border-primary/40' : 'border-border hover:border-foreground/15',
      )}
    >
      <div className="flex items-start gap-3">
        <div
          className="flex size-11 shrink-0 items-center justify-center rounded-full bg-secondary font-mono text-sm font-semibold text-foreground ring-1 ring-border"
          aria-hidden="true"
        >
          {getInitials(attendee.name)}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <h3 className="truncate font-semibold leading-tight">{attendee.name}</h3>
            {isYou && (
              <span className="shrink-0 rounded bg-primary/15 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-primary">
                You
              </span>
            )}
          </div>
          <p className="mt-1 text-sm leading-snug text-muted-foreground text-pretty">{attendee.role}</p>
        </div>
      </div>

      <div className="mt-4 flex items-center justify-between gap-2">
        <span
          className={cn(
            'inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset',
            styles.badge,
          )}
        >
          <span className={cn('size-1.5 rounded-full', styles.dot)} aria-hidden="true" />
          {attendee.tag}
        </span>
        <time suppressHydrationWarning className="font-mono text-xs text-muted-foreground" dateTime={new Date(attendee.checkedInAt).toISOString()}>
          {formatCheckIn(attendee.checkedInAt, now)}
        </time>
      </div>

      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        aria-controls={panelId}
        className="mt-4 inline-flex items-center justify-between gap-2 rounded-lg border border-border bg-secondary/60 px-3 py-2 text-sm font-medium transition-colors hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        <span className="inline-flex items-center gap-2">
          <MessageCircle className="size-4 text-primary" aria-hidden="true" />
          Icebreaker
        </span>
        <ChevronDown
          className={cn('size-4 text-muted-foreground transition-transform duration-200', open && 'rotate-180')}
          aria-hidden="true"
        />
      </button>

      <div
        id={panelId}
        className={cn(
          'grid transition-[grid-template-rows,opacity] duration-300 ease-out',
          open ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0',
        )}
      >
        <div className="overflow-hidden">
          <p className="mt-3 rounded-lg border-l-2 border-primary bg-primary/5 px-3 py-2.5 text-sm leading-relaxed text-foreground/90 text-pretty">
            {`"${attendee.icebreaker}"`}
          </p>
        </div>
      </div>
    </article>
  )
}
