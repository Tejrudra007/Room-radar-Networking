export const TAGS = ['Tech', 'Design', 'Founders', 'Marketing'] as const
export type Tag = (typeof TAGS)[number]

export type Attendee = {
  id: string
  name: string
  role: string
  tag: Tag
  icebreaker: string
  checkedInAt: number
}

export const TAG_STYLES: Record<Tag, { badge: string; dot: string }> = {
  Tech: {
    badge: 'bg-sky-400/10 text-sky-300 ring-sky-400/30',
    dot: 'bg-sky-400',
  },
  Design: {
    badge: 'bg-fuchsia-400/10 text-fuchsia-300 ring-fuchsia-400/30',
    dot: 'bg-fuchsia-400',
  },
  Founders: {
    badge: 'bg-amber-400/10 text-amber-300 ring-amber-400/30',
    dot: 'bg-amber-400',
  },
  Marketing: {
    badge: 'bg-orange-400/10 text-orange-300 ring-orange-400/30',
    dot: 'bg-orange-400',
  },
}

const minutesAgo = (m: number) => Date.now() - m * 60_000

export const SEED_ATTENDEES: Attendee[] = [
  {
    id: 'seed-1',
    name: 'Rahul Sharma',
    role: 'B.Tech Computer Science · 3rd Year',
    tag: 'Tech',
    icebreaker: 'Ask me about the campus placement-prep app I built during summer break.',
    checkedInAt: minutesAgo(2),
  },
  {
    id: 'seed-2',
    name: 'Kartik Reddy',
    role: 'B.Tech Mechanical Engineering · Final Year',
    tag: 'Founders',
    icebreaker: 'Ask me about my heavy machinery rental startup, InfraStack!',
    checkedInAt: minutesAgo(5),
  },
  {
    id: 'seed-3',
    name: 'Ananya Iyer',
    role: 'B.Des Communication Design · 2nd Year',
    tag: 'Design',
    icebreaker: 'Ask me how I redesigned our college fest app in a weekend hackathon.',
    checkedInAt: minutesAgo(8),
  },
  {
    id: 'seed-4',
    name: 'Sneha Patil',
    role: 'BA Economics · 3rd Year',
    tag: 'Marketing',
    icebreaker: 'Ask me how our Instagram campaign doubled footfall at the E-Cell summit.',
    checkedInAt: minutesAgo(11),
  },
  {
    id: 'seed-5',
    name: 'Aditya Verma',
    role: 'MSc Chemistry · Research Scholar',
    tag: 'Tech',
    icebreaker: 'Ask me about using machine learning to predict reaction yields in our lab.',
    checkedInAt: minutesAgo(15),
  },
  {
    id: 'seed-6',
    name: 'Priya Nair',
    role: 'B.Tech Electrical Engineering · Final Year',
    tag: 'Founders',
    icebreaker: 'Ask me about the low-cost solar kits we are piloting in nearby villages.',
    checkedInAt: minutesAgo(19),
  },
]

const ICEBREAKER_TEMPLATES: Record<Tag, (role: string) => string> = {
  Tech: (role) => `Ask me what I'm building right now as a ${role}.`,
  Design: (role) => `Ask me about a design decision I'd make differently as a ${role}.`,
  Founders: (role) => `Ask me what problem I'd start a company around as a ${role}.`,
  Marketing: (role) => `Ask me how I'd get the first 1,000 users as a ${role}.`,
}

export function buildIcebreaker(tag: Tag, role: string) {
  return ICEBREAKER_TEMPLATES[tag](role.trim() || 'newcomer')
}

export function getInitials(name: string) {
  return name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? '')
    .join('')
}

export function formatCheckIn(timestamp: number, now: number) {
  const minutes = Math.max(0, Math.round((now - timestamp) / 60_000))
  if (minutes < 1) return 'Just now'
  if (minutes === 1) return '1 min ago'
  return `${minutes} min ago`
}
